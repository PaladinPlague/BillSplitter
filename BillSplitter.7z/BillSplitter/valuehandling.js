var conversion = localStorage.getItem('conversionId');
var conversionrate = localStorage.getItem('conversionrateId');
function convertCurrency(x){
    conversion = x;
    if(conversion == "€"){
        conversionrate = 0.84;
    }else if(conversion == "$"){
        conversionrate = 0.74;
    }else if(conversion == "¥"){
        conversionrate = 0.0064;
    }else if(conversion == "Лв."){
        conversionrate = 0.43;
    }else if(conversion == "Kč"){
        conversionrate = 0.034;
    }else if(conversion == "Kr."){
        conversionrate = 0.079;
    }else if(conversion == "£"){
        conversionrate = 1;
    }else if(conversion == "Ft"){
        conversionrate = 0.0023;
    }else if(conversion == "Kr."){
        conversionrate = 0.18;
    }else if(conversion == "lei"){
        conversionrate = 0.17;
    }else if(conversion == "Skr"){
        conversionrate = 0.079;
    }else if(conversion == "CHf"){
        conversionrate = 0.80;
    }else if(conversion == "Ikr"){
        conversionrate = 0.0059;
    }else if(conversion == "Nkr"){
        conversionrate = 0.083;
    }else if(conversion == "kn"){
        conversionrate = 0.11;
    }else if(conversion == "₽"){
        conversionrate = 0.0095;
    }else if(conversion == "₺"){
        conversionrate = 0.055;
    }else if(conversion == "A$"){
        conversionrate = 0.53;
    }else if(conversion == "C$"){
        conversionrate = 0.58;
    }else if(conversion == "C¥"){
        conversionrate = 0.12;
    }else if(conversion == "₪"){
        conversionrate = 0.23;
    }else if(conversion == "₹"){
        conversionrate = 0.0098;
    }
    alert("Currency Changed to " + conversion);
    localStorage.setItem('conversionId', conversion);
    localStorage.setItem('conversionRateId', conversionrate);
}

function addValue(n){
    if (document.getElementById("price").value === "0") {
        document.getElementById("price").value = n;
    }else{
        var x = document.getElementById("price").value;
        document.getElementById("price").value = x + n;
    }
}
function clearValue(){
    document.getElementById("price").value = null;
    document.getElementById("textdetail").innerHTML = "";
    document.getElementById("split").value = null;
}

function splitBill(n) {

        var x = document.getElementById("price").value;
        var y = document.querySelector('input[name="tip"]:checked').value;
        var z = document.querySelector('input[name="rnd"]:checked').value;
        var price = ((x/n)* y).toFixed(2);
        document.getElementById("split").value = conversion + " " + price;
        document.getElementById("price").value = null;
        var tip = Math.ceil(price/z)*z;
        var ptip = tip * conversionrate;
        document.getElementById("textdetail").innerHTML = (conversion + " " + x + " split " + n + " ways is " + conversion + " " + (x/n).toFixed(2) + " each. <br>" +
        "Adding a tip and rounding to the nearest " + conversion + " " + z + " gives " + conversion + " " +  tip + " (approx. £" + ptip + ") each, including a tip of " + conversion
        + " " +  (x * (y-1)).toFixed(2));

    }


$(function(){
    $('input[type=radio]').each(function()    {
        var state = JSON.parse( localStorage.getItem('radio_'  + this.id) );

        if (state) this.checked = state.checked;
    });
});

$(window).bind('unload', function(){
    $('input[type=radio]').each(function()    {
        localStorage.setItem(
            'radio_' + this.id, JSON.stringify({checked: this.checked})
        );
    });
});

function myFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
    if (!event.target.matches('.dropbtn')) {
        var dropdowns = document.getElementsByClassName("dropdown-content");
        var i;
        for (i = 0; i < dropdowns.length; i++) {
            var openDropdown = dropdowns[i];
            if (openDropdown.classList.contains('show')) {
                openDropdown.classList.remove('show');
            }
        }
    }
}

